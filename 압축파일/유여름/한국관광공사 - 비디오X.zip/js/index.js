


const menuon = document.querySelectorAll(".mainMenu .gnb > li");

console.log(menuon);


for(let i=0; i<menuon.length; i++){
    menuon[i].onmouseenter = function(){
        for(let j=0; j<menuon.length; j++){
            menuon[j].classList.remove("on");
        }
        menuon[i].classList.add("on");
    }
    menuon[i].onmouseleave = function(){
        menuon[i].classList.remove("on")
    }
}




// 서브 cont


const subtitle = document.querySelectorAll(".subtext li");
    for(let i=0; i<subtitle.length; i++){
        subtitle[i].onmouseenter = function(){
            for(let j=0; j<subtitle.length; j++){
                subtitle[j].classList.remove("on");
            }
            subtitle[i].classList.add("on");
        }
    }


    const showimg = document.querySelectorAll(".showlist > div");
    const prevBtn = document.querySelector(".prevBtn");
    const nextBtn = document.querySelector(".nextBtn");
    const circles = document.querySelectorAll(".circles li");
    prevBtn.onclick = function(event){
        event.preventDefault();
        if(slideNum == 0){
            slideNum = showimg.length - 1;
        }
        else{
            slideNum-=1;
        }
        slideMoction();
    }
    nextBtn.onclick = function(event){
        event.preventDefault();
        slideAll();
        slideMoction();
    }
    let slideNum = 0;

    for(let j=0; j<showimg.length; j++){
        circles[j].onclick = function(){
            slideNum = j ; 
            slideMoction();
        }
    }


let autoSilde = setInterval(function(){
    slideAll();
    slideMoction();
},5000)

function slideAll(){
    if(slideNum == showimg.length-1){
        slideNum =0;
    }
    else{
        slideNum += 1;
    }
}
function slideMoction(){
    for(let i=0; i < showimg.length; i++){
        circles[i].classList.remove("on");
        showimg[i].style.opacity = 0;
        showimg[i].style.zIndex = 1;
    }
    circles[slideNum].classList.add("on");
    showimg[slideNum].style.opacity = 1;
    showimg[slideNum].style.zIndex = 15;
}
slideMoction (showimg)


// 보도자료


const contTopone = document.querySelector("#subcont1");
const contToptwo = document.querySelector("#subcont1_1");
const listboxs = document.querySelectorAll(".newList > div");
const headeron = document.querySelector("#header");
const headerimg = document.querySelector(".top_left h1 img");


console.log(headerimg);


window.onscroll = function(){
    let scTop = window.scrollY;
    if(scTop > 0){
        headeron.classList.add("on");
        headerimg.setAttribute("src","img/footerlogo_.svg");
    }
    else{
        headeron.classList.remove("on");
        headerimg.setAttribute("src","img/logo.svg");
    }


    if(scTop > contTopone.offsetTop){
        for(let i=0; i<listboxs.length; i++){
            listboxs[i].classList.add("on");
        }
    }
    else{
        for(let i=0; i<listboxs.length; i++){
            listboxs[i].classList.remove("on");
        }
    }
}