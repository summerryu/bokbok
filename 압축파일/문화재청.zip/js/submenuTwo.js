

const tabMenu = document.querySelectorAll("#container .center .submain .sub_left .menu li");

const subMain = document.querySelector("#container .center .submain .sub_main");
const subMaintwo = document.querySelector("#container .center .submain .sub_main_two");



tabMenu[0].onclick = function(){
    subMain.classList.add("on");
    subMaintwo.classList.remove("on");
}
tabMenu[1].onclick = function(){
    subMain.classList.remove("on");
    subMaintwo.classList.add("on");
}